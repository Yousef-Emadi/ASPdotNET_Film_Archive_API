﻿$(function () {

    function DisplayResult1(call, data) {
        $('#result').innerHTML = "";
        $('#result').append("<strong>" + call + "<strong>" + "<br/>");

        $.each(data, function (i, item) {

            $('#result').append(JSON.stringify(item));
            $('#result').append("<br/>");
        });
    };

    function DisplayResult2(call, data) {
        $('#result').innerHTML = "";

        $('#result').append("<strong>" + call + "<strong>" + "<br/>");

        $('#result').append(JSON.stringify(data));
        $('#result').append("<br/>");

    };
    //change the below port num. The below url is the MVC APP Backend 
    var serviceUrl = 'https://localhost:44357/api';


    $('#GetAll').on('click', function () {
        alert("All Items in ZOE Film Archive Inventory");
        $.ajax({
            url: serviceUrl + '/ZoeFilmAPI',
            method: 'GET',
            success: function (data) {
                DisplayResult1("Get All:", data);
            }
        });
    });


    $('#GetById').on('click', function () {
        var filmId = $('#Id').val();
        $.ajax({
            url: serviceUrl + '/ZoeFilmAPI/ ' + filmId,
            method: 'GET',
            success: function (data) {
                DisplayResult2("Film by id:", data);
            }
        });
    });


    //$('#AddFilm').on('click', function () {

    //    var inputData = {};
    //    inputData.Id = $('#Id').value();
    //    inputData.Title = $('#Title').value();
    //    inputData.ReleaseDate = $('#ReleaseDate').value();
    //    inputData.Price = $('#Price').value();
    //    inputData.Genre = $('#Genre').value();
    //    inputData.Rating = $('#Rating').value();



    //    $.ajax({
    //        url: serviceUrl + '/ZoeFilmAPI/',
    //        method: 'POST',
    //        data: '{' + JSON.stringify(inputData) + '}',
    //        contentType: "application/json; charset=utf-8",
    //        dataType: "json",
    //        success: function (data) {
    //            DisplayResult2("Add Film", data);
    //        }
    //    });
    //});


    $('#AddFilm').on('click', function () {
        

        var inputData = $('input').serialize();
        alert("bye");

        $.ajax({
            url: serviceUrl + '/ZoeFilmAPI/',
            method: 'POST',
            /*data: inputData,*/
            data: '{"id":30,"title":"Avatar","releaseDate":"1995-01-21T00:00:00","price":12,"genre":"Noir","rating":"PG"}',
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            success: function (data) {
                alert("bingo");

                DisplayResult2("Add Film", data);
            }
        });
    });


    $('#UpdateFilm').on('click', function () {
        var inputData = $('input').serialize();
        var filmId = $('#Id').val();
        $.ajax({
            url: serviceUrl + '/ZoeFilmAPI/' + filmId,
            method: 'PUT',
            data: inputData,
            success: function (data) {
                DisplayResult1("Updated list:", data);
            }
        });
    });


    //$('#AddCost').on('click', function () {
    //    var inputData = $('input').serialize();
    //    var bookId = $('#BookId').val();
    //    //alert(bookId);
    //    $.ajax({
    //        url: serviceUrl + '/ZoeFilmAPI/updatecost/' + bookId,
    //        method: 'PUT',
    //        data: inputData,
    //        success: function (data) {
    //            DisplayResult2("Add Cost", data);
    //        }
    //    });
    //});

});